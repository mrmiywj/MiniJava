a = b;
b = a + (foo + bar) + baz;
display baz;
display b;
